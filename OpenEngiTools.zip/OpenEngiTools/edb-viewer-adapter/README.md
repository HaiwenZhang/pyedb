# edb-viewer-adapter

EDB &rarr; [layout-viewer](https://github.com/ansys/layout_viewer) scene adapter.

This package bridges [PyEDB](https://github.com/ansys/pyedb) gRPC layout data and the
Qt/RHI `layout-viewer` frontend. It converts EDB geometry (traces, polygons, padstacks,
components) into the detached `layout_viewer.scene.LayoutScene` representation, and
subscribes to PyEDB's layout-change event stream (`pyedb.grpc.database.layout_changes`)
to support live, incremental viewer updates.

Importing `viewer_adapter` does not load Qt; only `launch_viewer()` does, and it raises
an actionable `ImportError` if `layout-viewer` is not installed.

## Installation

```bash
pip install edb-viewer-adapter
```

## Usage

```python
from pyedb import Edb
from viewer_adapter import launch_viewer

edb = Edb("my_design.aedb", edbversion="2025.1")
launch_viewer(edb)
```

## License

MIT. See `LICENSE`.
